
__author__="Mark Liu"
__date__ ="$28/09/2009 1:18:30 PM$"

if __name__ == "__main__":
    print "Hello";